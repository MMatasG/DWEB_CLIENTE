//Ejercicio 1
var numeromayor = parseInt(0);
function maximo(v1,v2,v3,v4) {
    document.write("Calculando maximo= ");
    return Math.max(v1,v2,v3,v4);
    }

document.write(maximo(1,2,3,4));


