//Ejercicio 8
var items = new Array();

function dados() {
    dado1 = Math.floor(Math.random() * 6) + 1;
    dado2 = Math.floor(Math.random() * 6) + 1;
    suma = dado1 + dado2;
    return suma;
  }
document.write(dados());


var a2 = 0;
var a3 = 0;
var a4 = 0;
var a5 = 0;
var a6 = 0;
var a7 = 0;
var a8 = 0;
var a9 = 0;
var a10 = 0;
var a11 = 0;
var a12 = 0;

    

for (var i = 1; i = 10; i++) {
    tirada = dados();
    
    if (tirada == 2) {
        var a2 = a2 + 1;
    } else if (tirada == 3) {
        var a3 = a3 + 1;
    } else if (tirada == 3) {
        var a4 = a4 + 1;
    } else if (tirada == 3) {
        var a5 = a5 + 1;
    } else if (tirada == 3) {
        var a5 = a5 + 1;
    } else if (tirada == 3) {
        var a5 = a5 + 1;
    } else if (tirada == 3) {
        var a5 = a5 + 1;
    } else if (tirada == 3) {
        var a5 = a5 + 1;
    } else if (tirada == 3) {
        var a5 = a5 + 1;
    } else if (tirada == 3) {
        var a5 = a5 + 1;
    } else if (tirada == 3) {
        var a5 = a5 + 1;
    } else if (tirada == 3) {
        var a5 = a5 + 1;
    }

    
 }
 document.write("2 = ", a2);
 document.write("3 = ", a3);
 document.write("4 = ", a4);
 document.write("4 = ", a5);
 document.write("5 = ", a6);
 document.write("6 = ", a7);
 document.write("7 = ", a8);
 document.write("8 = ", a9);
 document.write("9 = ", a10);
 document.write("10 = ", a11);
 document.write("11 = ", a12);
 document.write("12 = ", a13);